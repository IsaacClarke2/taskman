# Apple Notes Shortcut — Инструкция по созданию

## Обзор

Apple Notes не имеет публичного API. Единственный способ автоматически создавать заметки — через iOS Shortcuts.

Мы создадим Shortcut, который:
1. Получает webhook с данными заметки
2. Создаёт заметку в Apple Notes

---

## Вариант 1: Через IFTTT (проще)

### Настройка

1. Пользователь регистрируется на ifttt.com
2. Создаёт applet: Webhook → iOS Notes
3. Получает webhook URL
4. Вводит webhook URL в нашей панели

### Минусы
- Зависимость от IFTTT
- Задержка 1-15 секунд
- IFTTT Pro для большого количества запросов

---

## Вариант 2: Нативный Shortcut (рекомендуется)

### Как создать Shortcut файл

К сожалению, программно создать .shortcut файл сложно (проприетарный формат).

**Решение:** Создать Shortcut вручную и экспортировать как iCloud ссылку.

### Шаги создания Shortcut:

1. **Открой Shortcuts app на iPhone/iPad/Mac**

2. **Создай новый Shortcut с именем "AI Assistant Note"**

3. **Добавь actions:**

```
1. [Get Contents of URL]
   - URL: (будет передан как input)
   - Method: GET
   
2. [Get Dictionary from Input]

3. [Get Dictionary Value]
   - Key: "title"
   - Save to variable: noteTitle

4. [Get Dictionary Value]  
   - Key: "content"
   - Save to variable: noteContent

5. [Create Note]
   - Body: [noteContent variable]
   - Name: [noteTitle variable]
   - Folder: (выбрать папку или оставить default)
```

4. **Настрой автоматизацию:**
   - Automations → Create Personal Automation
   - Trigger: "When I receive a notification from [Your App]" 
   - Action: Run "AI Assistant Note" shortcut

### Альтернативный подход: Clipboard Bridge

Более простой вариант без сложной автоматизации:

1. **Наш бот отправляет пользователю сообщение:**
   ```
   📓 Заметка готова к сохранению!
   
   Заголовок: {title}
   
   {content}
   
   [📋 Скопировать в буфер] [📓 Открыть Apple Notes]
   ```

2. **При нажатии "Скопировать":**
   - Копируем форматированный текст в буфер
   - Открываем deep link: `mobilenotes://`

3. **Пользователь вставляет из буфера в Notes**

**Это не автоматизация, но это работает на 100% устройств без настройки.**

---

## Вариант 3: Push + Shortcut Automation

### Механизм

1. Регистрируем пользователя в Push Notifications (через наш web app)
2. При создании заметки отправляем Push с данными
3. Shortcut Automation срабатывает на Push
4. Shortcut создаёт заметку

### Реализация на бэкенде

```python
# api/services/apple_notes.py

import httpx
from typing import Optional

async def send_note_via_push(
    user_push_token: str,
    title: str,
    content: str
) -> bool:
    """
    Отправляет push notification с данными заметки.
    Пользователь настраивает Shortcut Automation для обработки.
    """
    
    # Используем APNs или Firebase
    # Payload содержит данные для Shortcut
    payload = {
        "aps": {
            "alert": {
                "title": "New Note",
                "body": title
            },
            "category": "CREATE_NOTE"
        },
        "note_title": title,
        "note_content": content
    }
    
    # Отправка через APNs...
    pass
```

### Shortcut Automation на устройстве

```
Trigger: When I receive a notification containing "CREATE_NOTE"

Actions:
1. Get [Shortcut Input]
2. Get Dictionary Value for "note_title"
3. Get Dictionary Value for "note_content"  
4. Create Note with title and content
```

---

## Рекомендация для MVP

**Используй Вариант 2 (Clipboard Bridge):**

1. Не требует сложной настройки от пользователя
2. Работает на всех устройствах
3. Можно реализовать за час

**UX Flow:**
```
User: [отправляет сообщение с заметкой]

Bot: 📓 Готово к сохранению в Apple Notes!

     Заголовок: Идея для геймификации
     ───────────────────────
     Сделать достижения за регулярные платежи
     в мобильном банке...
     
     [📋 Скопировать] [📓 Открыть Notes] [✗ Отмена]

User: [нажимает "Скопировать"]

Bot: ✓ Скопировано! Вставьте в Apple Notes.
     [📓 Открыть Notes]
```

**Код для Telegram:**
```python
# bot/keyboards/inline.py

def apple_notes_keyboard(note_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text="📋 Скопировать",
                callback_data=f"copy_note:{note_id}"
            ),
            InlineKeyboardButton(
                text="📓 Открыть Notes", 
                url="mobilenotes://"
            )
        ],
        [
            InlineKeyboardButton(
                text="✗ Отмена",
                callback_data=f"cancel_note:{note_id}"
            )
        ]
    ])
```

---

## Инструкция для пользователя (в web panel)

```markdown
## Подключение Apple Notes

Apple Notes не имеет открытого API, поэтому заметки сохраняются 
через буфер обмена.

### Как это работает:

1. Вы отправляете заметку боту
2. Бот форматирует её и предлагает скопировать
3. Вы нажимаете "Скопировать" → "Открыть Notes"
4. В Apple Notes нажимаете "Вставить"

### Автоматизация (опционально):

Если вы хотите полную автоматизацию, настройте iOS Shortcut:

1. Скачайте наш Shortcut: [Ссылка]
2. Разрешите запуск из уведомлений
3. Включите "Allow Untrusted Shortcuts" в настройках

После этого заметки будут создаваться автоматически.
```

---

## Файлы для создания

1. `web/app/integrations/apple-notes/page.tsx` — страница с инструкцией
2. `web/public/shortcuts/ai-assistant-note.shortcut` — файл Shortcut (если делаем)
3. `bot/handlers/notes.py` — обработчик для clipboard flow
